<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-22 06:28:21 --> Severity: Notice --> Undefined index: Msisdn G:\web\Xampp\htdocs\checkIsdn3\application\controllers\CheckIsdnController.php 24
